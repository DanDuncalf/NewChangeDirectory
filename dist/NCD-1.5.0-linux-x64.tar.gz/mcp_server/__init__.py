"""NCD MCP Server package."""
